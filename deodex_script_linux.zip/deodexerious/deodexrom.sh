frameworkPath=rom/system/framework
appPath=rom/system/app

## app additional classpaths (add or remove if needed)
custom_bluetoothopp="-c :javax.obex.jar"
custom_bluetoothpbap="-c :javax.obex.jar"
custom_buddiesnow="-c :twframework"
custom_camera="-c :seccamera.jar"
custom_clockpackage="-c :twframework"
custom_contacts="-c :twframework"
custom_dialertabactivity="-c :twframework"
custom_dlna="-c :twframework"
custom_email="-c :javax.obex.jar:twframework"
custom_factorytest="-c :seccamera.jar"
custom_fmradio="-c :twframework"
custom_infoalarm="-c :twframework:com.google.android.maps.jar"
custom_jobmanager="-c :twframework"
custom_minidiary="-c :com.google.android.maps.jar"
custom_musicplayer="-c :twframework"
custom_samsungwidget_calendarclock="-c :twframework"
custom_samsungwidget_feedandupdate="-c :twframework"
custom_samsungwidget_programmonitor="-c :twframework"
custom_samsungwidget_stockclock="-c :twframework"
custom_samsungwidget_weatherclock="-c :twframework"
custom_selftestmode="-c :seccamera.jar"
custom_settings="-c :twframework"
custom_sinanews="-c :twframework"
custom_soundplayer="-c :twframework"
custom_syncmlds="-c :twframework"
custom_touchwizcalendar="-c :com.google.android.maps.jar"
custom_videoplayer="-c :twframework"
custom_voicerecorder="-c :twframework"

## framework additional classpaths (add or remove if needed)
custom_android_policy="-c :core-junit.jar"
custom_ext="-c :core-junit.jar"
custom_framework="-c :core-junit.jar"
custom_services="-c :core-junit.jar"


echo Cleaning last deodexed rom files
rm -rf deodexed/app/*
rm -rf deodexed/framework/*

echo --------------------------------------------------------------
echo copy other framework files
echo --------------------------------------------------------------
cp $frameworkPath/*.apk deodexed/framework/

echo --------------------------------------------------------------
echo copy other app files
echo --------------------------------------------------------------
cp $appPath/*.apk deodexed/app/

echo --------------------------------------------------------------
echo Deodexing framework files
echo --------------------------------------------------------------

for f in $frameworkPath/*.odex
do
	basePath=${f%.*}
	baseFile=${basePath##*/}
	replvar=${baseFile//./_}
	replvar=${replvar//-/_}
	replvar=${replvar,,}
	eval custom=\$custom_${replvar}
	./deodexjar.sh $f "$custom"
	mv kitchen/ready/$baseFile.jar deodexed/framework/
done

echo -------------------------------------------------------------
echo Deodexing app files
echo -------------------------------------------------------------

for f in $appPath/*.odex
do
	if [ "$f" != "*.odex" ]; then
		basePath=${f%.*}
		baseFile=${basePath##*/}
		replvar=${baseFile//./_}
		replvar=${replvar//-/_}
		replvar=${replvar,,}
		eval custom=\$custom_${replvar}
		./deodexapk.sh $f "$custom"
		mv kitchen/ready/$baseFile.apk deodexed/app/
	fi
done
