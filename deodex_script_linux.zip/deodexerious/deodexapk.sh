odexPath=$1
basePath=${1%.*}
apkPath=$basePath.apk
baseFile=${basePath##*/}

echo Cleaning up
rm -rf kitchen/decompiled/*
rm -rf kitchen/build/*

echo Extract $baseFile.apk
cp $apkPath kitchen/ready/

echo Decompiling $basePath
java -Xss10m -Xmx512M -jar lib/baksmali-1.2.6.jar $2 -d deodexed/framework/ -d deodexed/app/ -d rom/system/framework/ -d rom/system/app/ -x $odexPath -o kitchen/decompiled

echo Compiling classes.dex from $basePath
java -Xss10m -Xmx512M -jar lib/smali-1.2.6.jar -o kitchen/build/classes.dex kitchen/decompiled

echo Packing
cd kitchen/build/
zip -uq ../ready/$baseFile.apk classes.dex
cd ..
cd ..

echo Cleaning up
rm -rf kitchen/decompiled/*
rm -rf kitchen/build/*
rm -f kitchen/ready/$baseFile.zip
rm -f kitchen/ready/${baseFile}_notzippedaligned.apk

echo Done.
