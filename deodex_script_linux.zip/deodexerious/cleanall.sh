echo Cleaning up
rm -rf deodexed/app/*
rm -rf deodexed/framework/*
rm -rf kitchen/decompiled/*
rm -rf kitchen/build/*
rm -rf kitchen/ready/*
